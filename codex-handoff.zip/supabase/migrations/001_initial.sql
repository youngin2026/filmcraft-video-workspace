begin;
create table public.plans (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 data jsonb not null,
 selected boolean not null default false,
 created_at timestamptz not null default now(),
 constraint plan_title check (coalesce(jsonb_typeof(data->'title') = 'string' and length(trim(data->>'title')) between 1 and 150, false)),
 constraint plan_theme check (coalesce(jsonb_typeof(data->'theme') = 'string' and length(trim(data->>'theme')) between 1 and 100, false)),
 constraint four_landmarks check (case when jsonb_typeof(data->'landmarks')='array' then jsonb_array_length(data->'landmarks')=4 else false end),
 constraint required_fields check (data ?& array['title','theme','landmarks'])
);
create table public.feedback (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 plan_id uuid not null references public.plans(id) on delete cascade,
 category text not null check (length(trim(category)) between 1 and 100),
 note text not null check (length(trim(note)) between 1 and 5000),
 created timestamptz not null default now()
);
create index plans_owner_created on public.plans(owner_id,created_at desc);
create index feedback_owner_created on public.feedback(owner_id,created desc);
alter table public.plans enable row level security;
alter table public.feedback enable row level security;
create policy plans_read on public.plans for select to authenticated using (owner_id=auth.uid());
create policy plans_insert on public.plans for insert to authenticated with check (owner_id=auth.uid());
create policy plans_update on public.plans for update to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy feedback_read on public.feedback for select to authenticated using (owner_id=auth.uid());
create policy feedback_insert on public.feedback for insert to authenticated with check (
 owner_id=auth.uid() and exists(select 1 from public.plans where id=plan_id and owner_id=auth.uid() and not selected)
);
-- 잠금으로 선정 변경과 피드백 저장이 동시에 실행되는 경우도 처리한다.
create function public.check_feedback_plan() returns trigger language plpgsql set search_path=public as $$
declare p public.plans;
begin
 select * into p from public.plans where id=new.plan_id for update;
 if p.id is null or p.owner_id<>auth.uid() or new.owner_id<>auth.uid() then raise exception '접근할 수 없는 기획입니다.'; end if;
 if p.selected then raise exception '제작 선정 기획은 선정 해제 후 피드백을 작성해주세요.'; end if;
 return new;
end; $$;
create trigger feedback_plan_check before insert on public.feedback for each row execute function public.check_feedback_plan();
grant select,insert,update on public.plans to authenticated;
grant select,insert on public.feedback to authenticated;
revoke all on public.plans,public.feedback from anon;
commit;
