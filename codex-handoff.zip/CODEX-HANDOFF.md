# 여행 쇼츠 기획실 — 다음 Codex 인수인계

확인일: 2026-11-15 (Asia/Seoul). 실제 DB와 현재 소스를 조회해 작성했다.
API 키·비밀번호·JWT·refresh token·Sites 서비스 토큰은 이 문서에 포함하지 않는다.

## 1. 프로젝트 식별 정보

- Supabase project ref: `agicohrtutvuvjikmdws`
- 프로젝트 이름: `youngin2026's Project`
- Project URL: `https://agicohrtutvuvjikmdws.supabase.co`
- REST base: `https://agicohrtutvuvjikmdws.supabase.co/rest/v1`
- Auth base: `https://agicohrtutvuvjikmdws.supabase.co/auth/v1`
- Dashboard: https://supabase.com/dashboard/project/agicohrtutvuvjikmdws
- 지역: `ap-southeast-1`
- Postgres: 17.11.0.019 (조회 당시)
- DB host: `db.agicohrtutvuvjikmdws.supabase.co` (직접 연결의 자격증명·포트·SSL 설정은 Dashboard Connect에서 확인; REST 사용에는 불필요)
- GitHub: https://github.com/youngin2026/travel-shorts-studio (private, main)
- Sites URL: https://travel-shorts-studio-youngin.awakemink2051.chatgpt.site
- Sites project ID: `appgprj_6af944670d1081919a60b0f9cec5236a`
- 현재 작업 checkout: `/workspace/sites/travel-shorts-sites`
- 이 환경이 바뀌면 로컬 경로 존재를 가정하지 말고 GitHub를 확인한다.
- 마지막 배포 확인: 관광지 소재 4개 2×2 표시 및 관광지 재사용 차단 버전.

## 2. 현재 저장 데이터

- public.plans: 5행 (초기 예시 2개 + 조사 초안 3개)
- public.feedback: 0행
- public.landmark_usage: 11행 (고유 관광지 사용 이력)
- 기존 초안 3개에 관광지 12항목, 소재 링크 48개. 초안끼리 후시미 이나리 중복이 있어 고유 관광지는 11곳.
- 초기 예시에도 중복이 있다. 기존 기획은 보존하고 UI에 중복 표시, 이후 신규 중복은 거부한다.
- 기존 데이터 owner UUID: `884a6ccd-b397-4d4c-ae12-6424d88c0619`.
  UUID는 인증 자격증명이 아니다. 새 계정으로 로그인하면 이 소유자의 데이터는 보이지 않는다.
  JWT의 실제 사용자와 owner_id를 맞추고 다른 소유자로 임의 변경하지 않는다.
- 계획 100개 생성은 사용자가 중지시켰다. 명시적 재개 전 자동으로 계속하지 않는다.
- 현재 DB 크기를 최근 앞선 조회에서 11MB로 확인. quota 잔여량을 검증한 값은 아니다.

## 3. 연결과 인증

### REST / 브라우저

필요한 값:
- SUPABASE_URL: 위 Project URL
- SUPABASE_ANON_KEY: 이 프로젝트의 활성 publishable key(권장) 또는 legacy anon key
- 로그인 사용자의 access_token (Bearer JWT)
- 갱신 시 refresh_token

공개키 조회:
- 연결된 Supabase 플러그인의 get_publishable_keys(project_id) 도구
- 또는 Dashboard API Keys
- disabled=true인 키는 사용하지 않는다.

사이트 Worker의 GET /api/config:
- Sites 환경변수 SUPABASE_URL, SUPABASE_ANON_KEY가 있으면 `{supabaseUrl,supabaseKey}` 반환
- 없으면 `{setupRequired:true}` 반환
- 이 경우 UI에서 입력한 공개 연결 정보를 localStorage `travel-studio-public-settings`에 보관
- 세션은 localStorage `travel-studio-session-v1`에 보관
- 타 환경의 Codex는 사용자의 브라우저 localStorage를 자동으로 읽을 수 없다.

일반 REST 헤더:
```
apikey: <publishable 또는 anon key>
Authorization: Bearer <로그인한 사용자의 access_token>
Content-Type: application/json
Prefer: return=representation
```

publishable key는 apikey 헤더에 넣는다. 사용자 JWT 대신 사용하지 않는다.
공개키만으로 private 테이블을 읽거나 쓸 수 없다.
service_role / sb_secret_ 키를 브라우저 코드나 GitHub에 넣지 않는다.
Sites 로그인/소유자 접근 정책과 Supabase Auth는 별개다.

### Auth 요청

POST /auth/v1/token?grant_type=password
헤더: apikey, Content-Type: application/json
본문: {"email":"로그인 이메일","password":"로그인 비밀번호"}
응답: access_token, refresh_token, expires_at, user.id 등을 포함한 세션.

POST /auth/v1/token?grant_type=refresh_token
본문: {"refresh_token":"실제 refresh token"}
반환된 refresh_token도 함께 교체한다. 현재 프런트는 만료 60초 전 갱신한다.

POST /auth/v1/logout
헤더: apikey, Authorization: Bearer <access_token>

사용자 비밀번호를 채팅으로 요청하지 않는다. 사용자가 로그인하거나 MCP로 관리 작업한다.

### Supabase 플러그인 / MCP

이 대화에서 연결 성공했으며 다음 도구를 사용했다:
- list_projects
- list_tables(project_id, schemas:["public"], verbose:true)
- execute_sql(project_id, query)
- get_project_url / get_publishable_keys
- apply_migration / get_advisors

다음 세션에서도 도구 활성화를 먼저 확인한다. Supabase 스킬을 읽고 따라야 한다.
관리 SQL은 사용자 JWT 기반 REST와 다르다. auth.uid() 기본값이 없는 관리 쿼리에서는 owner_id를 명시해야 한다.
MCP가 연결되면 API 키나 DB 비밀번호를 별도로 전달받지 않고 관리 작업할 수 있다.

## 4. DB 스키마

모든 테이블은 public 스키마이며 RLS가 켜져 있다.

### plans

| 컬럼 | 타입 | 기본값 / 조건 |
|---|---|---|
| id | uuid PK | gen_random_uuid() |
| owner_id | uuid NOT NULL | auth.uid(), auth.users(id) FK, 사용자 삭제 시 cascade |
| data | jsonb NOT NULL | 아래 기획 객체 |
| selected | boolean NOT NULL | false |
| created_at | timestamptz NOT NULL | now() |

DB CHECK: title 문자열 1~150자, theme 문자열 1~100자, landmarks 배열 정확히 4개, title/theme/landmarks 키 필수.
소재 4개와 원본 URL 검증은 주로 프런트 검증이다. 관리 SQL로 무효 데이터를 넣지 않는다.

### feedback

| 컬럼 | 타입 | 기본값 / 조건 |
|---|---|---|
| id | uuid PK | gen_random_uuid() |
| owner_id | uuid NOT NULL | auth.uid(), auth.users FK |
| plan_id | uuid NOT NULL | plans(id) FK, 기획 삭제 시 cascade |
| category | text NOT NULL | 공백 제거 후 1~100자 |
| note | text NOT NULL | 공백 제거 후 1~5000자 |
| created | timestamptz NOT NULL | now() |

주의: 기획은 created_at, 피드백은 created 컬럼이다.
미선정(selected=false) 기획에만 새 피드백을 저장한다. 기존 피드백은 선정 후에도 보존된다.
check_feedback_plan 트리거가 소유자와 미선정 상태를 확인하고 행 잠금을 사용한다.

### landmark_usage

| 컬럼 | 타입 | 설명 |
|---|---|---|
| owner_id | uuid NOT NULL | auth.users FK |
| place_key | text NOT NULL | 정규화된 장소명 |
| first_plan_id | uuid NOT NULL | 최초 사용 기획 ID; plans FK는 아님 |
| place_name | text NOT NULL | 원래 관광지 이름 |

복합 PK: (owner_id, place_key).
기획 트리거가 자동 기록한다. 기획의 관광지를 바꿔도 과거 기록은 남는다.
사용자에게 UPDATE/DELETE 권한은 주지 않았다. 앱에서 직접 usage 기록을 삭제하거나 다시 만들지 않는다.
현재 중복 방지 범위는 계정(owner_id)별 전체 기획이다. 계정 간 전역 중복 금지는 아니다.

## 5. JSON 데이터 계약

최상위 교환 파일:
```
{"plans":[<기획 객체>, ...]}
```
파일 업로드는 JSON만 지원한다. ZIP은 먼저 풀어야 한다.
최대 5MB, 1~1000개 기획.
DB 저장 시 최상위 plans 배열을 data에 통째로 넣으면 안 된다. 각 기획을 한 행의 data로 감싼다.

기획 객체(아래 URL은 자리표시자이며 실제 개별 원본 URL로 교체):
```json
{
  "title": "제목 TOP 4",
  "theme": "주제",
  "summary": "기획 설명",
  "review_status": "draft",
  "landmarks": [
    {
      "rank": 4,
      "name": "정식 관광지명",
      "country": "국가",
      "city": "도시 또는 지역",
      "description": "주제에 맞는 이유",
      "image": "https://이미지-직접-URL",
      "source": "https://www.pexels.com/photo/실제-소재-ID/",
      "verified": "확인한 범위와 남은 검수",
      "sources": [
        {"url":"https://www.pexels.com/photo/실제-소재-ID/","image":"https://이미지-직접-URL","type":"photo"}
      ]
    }
  ]
}
```
예시를 간결하게 하기 위해 landmarks와 sources 항목을 하나만 표시했다.
실제로는 landmarks 4개(rank 4→3→2→1), sources는 장소별 서로 다른 Pexels 소재 4개가 필수다.
image는 사진 직접 주소이고 source/url은 소재 원본 페이지다. 같은 용도가 아니다.
동영상은 검증된 포스터 이미지를 image로, 원본 비디오 페이지를 url로 제공한다.

중요한 형식 차이:
- 사용자에게 안내한 간단 입력은 rank/name/country/city/description/sources[].url만 포함한다.
- 현재 사이트 가져오기 파서는 관광지의 image와 source까지 필수로 요구한다.
- 따라서 다음 Codex가 간단 입력을 받으면 실제 메타데이터로 image/source와 각 sources[].image를 보완해야 한다.
- Pexels 사진의 URL 규칙으로 만든 미리보기가 실제로 표시되는지 검증한다. 동영상에 사진 규칙을 적용하지 않는다.
- 현재 UI는 배열 위치로 TOP 순서를 표시한다. rank 숫자만 바꾸지 말고 landmarks 순서를 맞춘다.
- sources 배열은 2×2 미리보기로 항상 표시된다. 소재가 없는 기존 예시는 빈칸에 미확보라고 나온다.

## 6. REST 요청 예시

아래 경로는 Supabase REST base 뒤에 붙인다. 브라우저는 위 공통 헤더를 사용한다.

### 조회

GET /plans?select=*&order=created_at.desc
GET /plans?id=eq.<plan-uuid>&select=*
GET /feedback?select=*&order=created.desc
GET /feedback?plan_id=eq.<plan-uuid>&select=*&order=created.desc
GET /landmark_usage?select=place_key,place_name,first_plan_id

응답은 행 배열이다. 예:
```
[{"id":"...","owner_id":"...","data":{...},"selected":false,"created_at":"..."}]
```
현재 getState()는 plans 행을 `{...row.data,id:row.id,selected:row.selected}`로 평탄화한다.
DB REST 원형과 UI의 평탄화 형식을 혼동하지 않는다.
기획/사용 이력이 커지면 limit/offset 또는 Range로 페이지를 모두 읽는다. 현재 앱은 단일 요청이며 대규모 누락 가능성은 점검 대상.

### 기획 생성

POST /plans
```
{"data":<기획 객체>,"selected":false}
```
id, owner_id, created_at은 일반 사용자 REST에서 생략할 수 있다.
배치 생성은 같은 구조의 행 배열을 POST한다. 하나라도 관광지 충돌이 나면 요청 전체가 실패할 수 있다.
신규 관광지를 landmark_usage에 미리 INSERT하지 않는다. 트리거가 처리한다.

### 제작 대상 선정 / 해제

PATCH /plans?id=eq.<plan-uuid>
```
{"selected":true}
```
해제는 false. 선정은 제작 대상 지정일 뿐 후속 검수나 렌더링 시작이 아니다.
PATCH가 200이어도 반환 배열이 []면 실제 행이 변경되지 않은 것이다. 응답 행 수를 확인한다.

### 피드백 생성

POST /feedback
```
{"plan_id":"<미선정 기획 UUID>","category":"문제 유형","note":"문제와 개선 방향"}
```
선정된 기획에는 저장 불가. 일반 사용자 REST에서는 owner_id 생략.

### 같은 파일 반복 가져오기

프런트가 기존 기획의 title+landmark names로 중복을 걸러낸 뒤 결정적 UUID를 계산한다.
POST /plans?on_conflict=id
헤더 Prefer: resolution=ignore-duplicates,return=representation
본문: [{"id":"<결정적 UUID>","data":<기획>,"selected":false}, ...]

ID 구현은 public/import-plans.js의 importId()를 그대로 사용한다:
planKey = JSON.stringify([title.trim().normalize('NFC'), landmarks.map(name.trim().normalize('NFC')).sort()])
SHA-256(owner + '\n' + planKey)의 hex로 코드의 지정 위치를 조합한 UUID.
독자 구현보다 해당 함수를 재사용한다.
DB BEFORE INSERT 트리거는 ON CONFLICT 이전에도 실행될 수 있다. 동일 기획은 먼저 조회해 건너뛰는 현재 절차를 유지한다.

## 7. RLS와 트리거 제약

plans: authenticated + owner_id=auth.uid() SELECT/INSERT/UPDATE.
UPDATE에는 USING과 WITH CHECK 모두 적용. 일반 사용자 DELETE 정책 없음.
feedback: 본인 행 SELECT, 본인 소유의 미선정 기획에만 INSERT. UPDATE/DELETE 정책 없음.
landmark_usage: 본인 이력 SELECT/INSERT. UPDATE/DELETE 정책 없음.
anon에는 세 테이블 접근 권한 없음.

관광지 중복 방지:
- DB landmark_key(name)와 프런트 landmarkKey(name)을 같이 유지한다.
- NFKC, 소문자, 공백/기호 제거 및 일부 알려진 한영 별칭 매핑.
- 센소지/가미나리몬, 도쿄타워/Tokyo Tower, 남산타워/N서울타워 등은 동일 키.
- 모든 별칭과 실제 장소를 자동 판별하는 완전한 지리 ID 시스템은 아니다.
- 새 별칭을 추가할 때 기존 usage 키에 미치는 영향도 점검한다.
- guard_landmark_reuse 트리거가 기획 내 중복, 기존 기획 관광지 재사용을 차단한다.
- selected 여부와 무관하게 사용한 장소는 재사용 금지.
- 기존 중복 기획에서 landmarks를 수정하면 이력 소유 기획과 충돌해 거부될 수 있다. 임의 우회 금지.

주요 오류:
- 401: 세션 만료 / JWT / 프로젝트 불일치
- 403 또는 RLS 오류: 로그인 사용자와 owner 불일치, grant/policy 문제
- 23514: CHECK 조건 불일치
- 23505: PK/unique 충돌
- P0001 또는 메시지 '이미 사용한 관광지입니다': 재사용 차단
- '제작 선정 기획은 선정 해제 후…': 피드백 제약
- API 성공 + []: 보이는 데이터가 없거나 PATCH 대상이 없음. 무조건 연결 실패로 해석하지 않는다.
- 용량 초과가 실제 확인되면 프로젝트 파일에 저장하고 실패 사유를 기록한다. 기존 데이터 삭제로 공간 확보하지 않는다.

## 8. 저장소 소스와 배포

- public/backend.js: Supabase Auth / REST / 가져오기
- public/app.js, public/index.html: UI
- public/import-plans.js: 입력 검증, 중복 기획 키, 결정적 UUID
- public/landmark-key.js: 관광지 정규화와 사용 여부 검사
- public/validation.js: 기획/소재 URL 검증
- public/settings.js: 공개 연결 설정 검증
- public/plans.json: 조사한 초안 3개
- public/examples.json: 과거 예시 (이제 신규 불러오기는 중복 때문에 차단)
- worker/index.js: Sites Worker. 실제 HTTP API는 GET /api/config 뿐; DB HTTP는 Supabase에 직접 요청한다.
  backend.js에 문자열로 있는 /api/plans, /api/select, /api/feedback는 내부 분기 키이며 Sites의 HTTP 엔드포인트가 아니다.
- worker/config.js: 환경변수 검사
- scripts/build.mjs: public 파일들을 Worker에 포함해 dist/server/index.js 생성
- .openai/hosting.json: 기존 Sites project_id 유지
- supabase/migrations/001_initial.sql: 초기 스키마. 운영 DB에 재실행 금지.
- docs/landmark-usage.sql: 이미 적용한 사용 이력 테이블/트리거. 재실행 금지.
- docs/requirements.md: 누적 요구사항
- data/planning/research/catalog.json: 이 작업 환경에 있는 명소 후보 검색 자료. 실제 화면 검수 완료 자료가 아니며 GitHub 업로드 여부를 확인해야 한다.

검사:
```
npm run build
npm test
```
직전 코드 테스트 10개 통과. 실제 브라우저 화면 검수는 아직 수행하지 못함.
Sites 소스 저장소와 GitHub는 별개다. GitHub push만으로 Sites가 자동 배포되지는 않는다.
Sites 스킬을 읽고 기존 project_id로 소스 동기화·빌드·배포한다. 새 사이트를 만들지 않는다.

## 9. 기존 DB 점검 결과 (미수정 항목)

이번 기능과 무관한 기존 advisor 항목도 확인됨:
- rls_auto_enable() SECURITY DEFINER 함수의 anon/authenticated 실행 권한
  https://supabase.com/docs/guides/database/database-linter?lint=0028_anon_security_definer_function_executable
- leaked password protection 비활성화
  https://supabase.com/docs/guides/auth/password-security#password-strength-and-leaked-password-protection
- feedback.plan_id FK 인덱스 미구성, 기존 RLS auth.uid() 재평가 관련 성능 항목
  https://supabase.com/docs/guides/database/database-linter?lint=0001_unindexed_foreign_keys
  https://supabase.com/docs/guides/database/database-linter?lint=0003_auth_rls_initplan
새 코드 때문에 생긴 것으로 단정하지 말고 필요 시 현재 advisor를 다시 조회한다.

## 10. 사용자 핵심 요구사항

- 한국에서 가기 쉬운 국내·해외 여행지, 도시명만 아닌 구체 관광지
- 주제별 관광지 TOP4, 관광지별 Pexels 개별 소재 4개
- 소재 4개를 한눈에 2×2 표시
- 한 번 사용한 관광지는 미선정 기획까지 포함해 재사용 금지
- 내레이션 없음, 단계별 사람이 검수
- 사람이 고른 기획만 제작 대상. 선정 자체로 영상 제작이나 다음 단계 자동 승인 금지
- 미선정 이유와 개선 피드백 저장 후 다음 기획에 반영
- 장기 목표 100개 기획, 고유 관광지 400곳, 소재 링크 1600개. 현재 3개 초안에서 중지됨.
- 실제 Pexels 페이지 설명/이미지 확인 상태를 구분하고 미검증 자료를 완료로 주장하지 않기
- 다음 Codex에게 기획 JSON을 주면 중복 검사, 소재/미리보기 보완 후 검수 대기로 DB 등록하는 역할
- 간단 입력 JSON과 현재 사이트 파서의 image/source 필수 차이를 반드시 처리
