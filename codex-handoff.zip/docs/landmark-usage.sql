create or replace function public.landmark_key(n text) returns text language plpgsql immutable set search_path='' as $$
declare k text := regexp_replace(lower(normalize(n,NFKC)), '[^[:alnum:]]','','g');
begin
return case
when k in ('센소지','센소지가미나리몬','가미나리몬','sensojitemple','sensoji') then 'sensoji'
when k in ('후시미이나리신사','후시미이나리','후시미이나리타이샤','fushimiinari','fushimiinaritaisha') then 'fushimi'
when k in ('도쿄타워','tokyotower') then 'tokyotower'
when k in ('n서울타워','남산타워','남산서울타워','nseoultower') then 'nseoultower'
when k in ('오사카성','osakacastle') then 'osakacastle'
when k in ('기요미즈데라','청수사','kiyomizudera') then 'kiyomizu'
when k in ('아라시야마대나무숲','아라시야마죽림','arashiyamabamboogrove') then 'arashiyama'
else k end;
end $$;
create table public.landmark_usage (
 owner_id uuid not null references auth.users(id) on delete cascade,
 place_key text not null,
 first_plan_id uuid not null,
 place_name text not null,
 primary key(owner_id,place_key)
);
alter table public.landmark_usage enable row level security;
create policy usage_read on public.landmark_usage for select to authenticated using (owner_id=(select auth.uid()));
create policy usage_insert on public.landmark_usage for insert to authenticated with check(owner_id=(select auth.uid()));
grant select,insert on public.landmark_usage to authenticated;
revoke all on public.landmark_usage from anon;
insert into public.landmark_usage(owner_id,place_key,first_plan_id,place_name)
select distinct on(p.owner_id,public.landmark_key(l->>'name')) p.owner_id,public.landmark_key(l->>'name'),p.id,l->>'name'
from public.plans p cross join lateral jsonb_array_elements(p.data->'landmarks') l
order by p.owner_id,public.landmark_key(l->>'name'),p.created_at,p.id;
create function public.guard_landmark_reuse() returns trigger language plpgsql set search_path='' as $$
declare l jsonb; k text; holder uuid; seen text[] := '{}';
begin
if TG_OP='UPDATE' and new.data->'landmarks'=old.data->'landmarks' then return new; end if;
for l in select * from jsonb_array_elements(new.data->'landmarks') loop
 k:=public.landmark_key(l->>'name');
 if k is null or k='' then raise exception '관광지 이름이 필요합니다.';end if;
 if k=any(seen) then raise exception '기획 안에 같은 관광지가 있습니다: %',l->>'name';end if;
 seen:=array_append(seen,k);
 insert into public.landmark_usage(owner_id,place_key,first_plan_id,place_name) values(new.owner_id,k,new.id,l->>'name') on conflict do nothing;
 select first_plan_id into holder from public.landmark_usage where owner_id=new.owner_id and place_key=k;
 if holder is distinct from new.id then raise exception '이미 사용한 관광지입니다: % (미선정 기획 포함)',l->>'name';end if;
end loop;
return new;
end $$;
create trigger plans_landmark_reuse before insert or update of data on public.plans for each row execute function public.guard_landmark_reuse();
