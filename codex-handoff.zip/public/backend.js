import {landmarkKey,assertUnused} from './landmark-key.js';
import {validateSettings} from './settings.js';
import {validatePlan} from './validation.js';
let config=null,session=null,refreshing=null;
const SESSION_KEY='travel-studio-session-v1';
function saveSession(s){session=s;try{if(s)localStorage.setItem(SESSION_KEY,JSON.stringify(s));else localStorage.removeItem(SESSION_KEY)}catch{}}
export async function configure(){
 const r=await fetch('/api/config');const data=await r.json();if(!r.ok)throw Error(data.error||'연결 설정을 불러올 수 없습니다.');
 let saved=null;try{saved=JSON.parse(localStorage.getItem('travel-studio-public-settings')||'null')}catch{}
 if(data.setupRequired&&!saved)return false;
 config=validateSettings(data.setupRequired?saved:data);try{session=JSON.parse(localStorage.getItem(SESSION_KEY)||'null')}catch{session=null}
 return Boolean(session?.access_token);
}
async function authRequest(path,body){
 const r=await fetch(config.supabaseUrl+'/auth/v1/'+path,{method:'POST',headers:{apikey:config.supabaseKey,'Content-Type':'application/json'},body:JSON.stringify(body)});
 const data=await r.json();if(!r.ok)throw Error(data.msg||data.error_description||data.message||'로그인에 실패했습니다.');return data;
}
export async function login(email,password){const s=await authRequest('token?grant_type=password',{email,password});saveSession(s);return s}
export async function logout(){try{await fetch(config.supabaseUrl+'/auth/v1/logout',{method:'POST',headers:{apikey:config.supabaseKey,Authorization:'Bearer '+session?.access_token}})}finally{saveSession(null)}}
async function token(){
 if(!session?.access_token)throw Error('로그인이 필요합니다.');
 if((session.expires_at||0)*1000<Date.now()+60000){
  if(!refreshing)refreshing=authRequest('token?grant_type=refresh_token',{refresh_token:session.refresh_token}).then(s=>{saveSession(s);return s}).catch(e=>{saveSession(null);throw Error('로그인이 만료되었습니다. 다시 로그인해주세요.')}).finally(()=>refreshing=null);
  await refreshing;
 }
 return session.access_token;
}
async function rest(path,options={}){
 const accessToken=await token();const r=await fetch(config.supabaseUrl+'/rest/v1/'+path,{...options,headers:{apikey:config.supabaseKey,Authorization:'Bearer '+accessToken,'Content-Type':'application/json',Prefer:'return=representation',...options.headers}});
 const body=await r.text();let data;try{data=body?JSON.parse(body):null}catch{data=null}
 if(!r.ok){if(r.status===401){saveSession(null);throw Error('로그인이 만료되었습니다. 다시 로그인해주세요.')}throw Error(data?.message||'저장에 실패했습니다. Supabase 테이블과 접근 정책을 확인해주세요.')}
 return data;
}
export async function getState(){const [plans,feedback]=await Promise.all([rest('plans?select=*&order=created_at.desc'),rest('feedback?select=*&order=created.desc')]);return {plans:plans.map(p=>({...p.data,id:p.id,selected:p.selected})),feedback}}
export async function mutate(path,data){
 if(path==='/api/plans'){validatePlan(data);const used=await rest('landmark_usage?select=place_key');assertUnused(data,used.map(x=>x.place_key));return rest('plans',{method:'POST',body:JSON.stringify({data})})}
 if(path==='/api/select')return rest('plans?id=eq.'+encodeURIComponent(data.id),{method:'PATCH',body:JSON.stringify({selected:!!data.selected})});
 if(path==='/api/feedback'){
  if(!data.note?.trim()||data.note.length>5000||!data.category)throw Error('문제 유형과 1~5000자 피드백을 입력해주세요.');
  return rest('feedback',{method:'POST',body:JSON.stringify({plan_id:data.id,category:data.category,note:data.note.trim()})});
 }
 throw Error('지원하지 않는 작업입니다.');
}
export async function addExamples(){throw Error('예시 기획은 중복 관광지를 포함해 추가할 수 없습니다. 새 기획을 등록해주세요.')}

export function hasConfiguration(){return Boolean(config)}
export function saveConfiguration(data){const next=validateSettings(data);localStorage.removeItem(SESSION_KEY);session=null;localStorage.setItem('travel-studio-public-settings',JSON.stringify(next));config=next;}

export async function importPlans(plans){
 const {parseImport,planKey,importId}=await import('./import-plans.js');const validated=parseImport(plans);
 await token();const owner=session.user.id;const existing=await getState();const keys=new Set(existing.plans.map(planKey));
 const pending=validated.filter(p=>!keys.has(planKey(p)));if(!pending.length)return {added:0,skipped:validated.length};
 const usedRows=await rest('landmark_usage?select=place_key');let used=new Set(usedRows.map(x=>x.place_key));for(const p of pending)used=assertUnused(p,used);
 const rows=await Promise.all(pending.map(async data=>({id:await importId(owner,data),data,selected:false})));
 const saved=await rest('plans?on_conflict=id',{method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=representation'},body:JSON.stringify(rows)});
 return {added:saved.length,skipped:validated.length-saved.length};
}
