export function validatePlan(p) {
 if(typeof p.title!=='string'||!p.title.trim()||p.title.length>150)throw Error('제목은 1~150자로 입력해주세요.');
 if(typeof p.theme!=='string'||!p.theme.trim()||p.theme.length>100)throw Error('주제는 1~100자로 입력해주세요.');
 if(!Array.isArray(p.landmarks)||p.landmarks.length!==4)throw Error('명소는 정확히 4곳을 입력해주세요.');
 for(const l of p.landmarks){
  if(!l.name?.trim())throw Error('각 명소의 이름이 필요합니다.');
  let image,source;try{image=new URL(l.image);source=new URL(l.source)}catch{throw Error('사진과 소재 원본의 URL을 확인해주세요.')}
  if(image.protocol!=='https:'||source.protocol!=='https:')throw Error('사진과 소재 링크는 HTTPS 주소를 사용해주세요.');
  if(!['pexels.com','pixabay.com'].some(h=>source.hostname===h||source.hostname.endsWith('.'+h)))throw Error('Pexels 또는 Pixabay 소재 원본 링크를 입력해주세요.');
  if(!/^\/(?:[a-z]{2}\/)?(?:photo|photos|video|videos)\/[^/]+-\d+\/?$/.test(source.pathname))throw Error('검색 페이지 대신 개별 사진·영상 원본 링크를 입력해주세요.');
 }
 return p;
}
