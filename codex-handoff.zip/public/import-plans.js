import {validatePlan} from './validation.js';
export function parseImport(input){
 const plans=Array.isArray(input)?input:input?.plans;
 if(!Array.isArray(plans)||!plans.length||plans.length>1000)throw Error('기획 1~1000개가 들어 있는 JSON 파일을 선택해주세요.');
 const result=[],seen=new Set();
 for(const p of plans){const {id,selected,owner_id,...data}=p;validatePlan(data);if(data.landmarks.some(l=>!Array.isArray(l.sources)||l.sources.length!==4))throw Error('각 명소에 소재 4개(sources)가 필요합니다.');
 for(const l of data.landmarks){const ids=new Set();for(const s of l.sources){validatePlan({...data,landmarks:data.landmarks.map(x=>x===l?{...l,source:s.url,image:s.image||l.image}:x)});const m=new URL(s.url).pathname.match(/-(\d+)\/?$/);if(!new URL(s.url).hostname.endsWith('pexels.com')||!m)throw Error('Pexels 개별 원본 링크가 필요합니다.');ids.add(m[1]);}if(ids.size!==4)throw Error('명소별 소재 4개는 서로 달라야 합니다.');}
 const key=planKey(data);if(!seen.has(key)){seen.add(key);result.push(data)}}return result;
}
export function planKey(p){return JSON.stringify([p.title.trim().normalize('NFC'),p.landmarks.map(l=>l.name.trim().normalize('NFC')).sort()])}
export async function importId(owner,p){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(owner+'\n'+planKey(p)));const h=Array.from(new Uint8Array(hash),x=>x.toString(16).padStart(2,'0')).join('');return h.slice(0,8)+'-'+h.slice(8,12)+'-5'+h.slice(13,16)+'-a'+h.slice(17,20)+'-'+h.slice(20,32)}
